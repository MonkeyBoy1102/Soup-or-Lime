package souporlime;

import java.util.Random;
import java.util.Scanner;


public class SouporLime {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Random rand = new Random();
        int value = rand.nextInt(2);
        
        if(value==0){
            String ans = ("Soup"); 
            System.out.println("Soup or Lime?");
            String answer = input.next();
            
            if(answer .equalsIgnoreCase(ans)){
                System.out.println("You win!");
            }
            else{
                System.out.println("Wrong! It was Soup");
            }
        }
        
        if(value==1){
           String ans = ("Lime"); 
            System.out.println("Soup or Lime?");
            String answer = input.next();
            
            if(answer .equalsIgnoreCase(ans)){
                System.out.println("You win!");
            }
            else{
                System.out.println("Wrong! It was Lime");
            } 
        }
    }
    
}
